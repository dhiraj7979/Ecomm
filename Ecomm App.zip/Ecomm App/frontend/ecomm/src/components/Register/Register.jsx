import React from 'react';
import './register.css';
import { Link } from 'react-router-dom';

function Register() {

    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [re_password, setRepassword] = React.useState('');
    const [error, setError] = React.useState('');
    const [loading, setLoading] = React.useState(false);

    const handleRegister = async (event) => {
        event.preventDefault();
        const response = await fetch(`${import.meta.env.VITE_API_URL}auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name,
                email,
                password,
                re_password
            })
        });

        const data = await response.json();

        if (data.success) {
            window.location.href = '/login';
        } else {
            alert('Registration failed!');
        }

    }

    return (
        <div className="register-container">
            <h1>ShopEasy</h1>

            <form onSubmit={handleRegister}>
                <label>
                    Name:
                    <input type="text" name="name" onChange={(e) => setName(e.target.value)} />
                </label>

                <label>
                    Email:
                    <input type="email" name="email" onChange={(e) => setEmail(e.target.value)} />
                </label>

                <label>
                    Password:
                    <input type="password" name="password" onChange={(e) => setPassword(e.target.value)} />
                </label>

                <label>
                    Confirm Password:
                    <input type="password" name="repassword" onChange={(e) => setRepassword(e.target.value)} />
                </label>

                <button type="submit">Register</button>
            </form>
            <span className='go-back-link'>
            <Link to="/login">Have an account? Login</Link>
            </span>
        </div>
    );
}

export default Register;
