import React from 'react';
import './resetPassword.css';
import { useNavigate } from 'react-router-dom';

function ResetPassword() {
    const [newPassword, setPassword] = React.useState('');
    const [re_password, setRepassword] = React.useState('');
    const [error, setError] = React.useState('');

    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const resetToken = urlParams.get('token');
    const navigate = useNavigate();

    console.log(resetToken, "token");

    const handlePasswordReset = async (event) => {
        event.preventDefault();
        try {
            const response = await fetch(`${import.meta.env.VITE_API_URL}auth/reset_password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    newPassword,
                    resetToken
                })
            });
            const data = await response.json();
            if (data.success) {
                alert('Password reset successful. Please login with your new password');
                navigate('/login');
            }
            else {
                alert('Password reset failed. Please try again');
            }
        } catch (error) {
            console.error(error);
            alert('Password reset failed. Please try again');
        }
    }


    return (
        <div className="reset-password-container">
            <h2>Reset Password</h2>

            <form onSubmit={handlePasswordReset}>
                <div className="form-group">
                    <label htmlFor="newPassword">New Password</label>
                    <input type="password" id="newPassword" />
                </div>

                <div className="form-group">
                    <label htmlFor="confirmPassword">Confirm Password</label>
                    <input type="password" id="confirmPassword" />
                </div>

                <button type="submit">Reset Password</button>
            </form>
        </div>
    );
}

export default ResetPassword;
