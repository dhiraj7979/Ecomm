import React from 'react';
import { Link } from 'react-router-dom';

import './forgotPassword.css';

const ForgotPassword = () => {
    const [email, setEmail] = React.useState('');
    const [error, setError] = React.useState('');

    const sendLink = async (event) => {
        event.preventDefault();
        try {
            const response = await fetch(`${import.meta.env.VITE_API_URL}auth/forgot_password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email
                })
            });
            const data = await response.json();
            if (data.success) {
                console.log(data.message);
                console.log(data.body);
                alert('Check your email for a reset link. (Or check ur browser console **Easter Egg**)) ');
            } else {
                alert('Email not found');
            }
            
        } catch (error) {
            console.error(error);
            alert('Oops! Something went wrong. Please try again later');
        }
    }

    return (
        <div className="forgotPassword">
            <div className="goBack">
                <Link to="/login">
                    <i className="fa fa-arrow-left"></i> Go Back
                </Link>
            </div>

            <div className="formWrapper">
                <form onSubmit={sendLink}>
                    <div className="formItem">
                        <label>Email</label>
                        <input type="email" name="email" required onChange={(e) => setEmail(e.target.value)} />
                    </div>

                    <div className="formItem">
                        <button type="submit">Send Reset Link</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ForgotPassword;