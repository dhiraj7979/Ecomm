import React, { useEffect, useState } from 'react';
import "./navbar.css";
import { useNavigate } from 'react-router-dom';
import '@fortawesome/fontawesome-svg-core/styles.css';
import { faPersonBooth, faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useSpinner } from '../../utils/SpinnerContext';

const Navbar = () => {
    const navigate = useNavigate();
    const [showProfileDropdown, setShowProfileDropdown] = useState(false);
    const {setIsLoading} = useSpinner();
    const [cartCount, setCartCount] = useState(0);

    const logout = async () => {
        setIsLoading(true);
        localStorage.removeItem('ecomm-user');
            try {
                const response = await fetch(`${import.meta.env.VITE_API_URL}auth/logout`, {method: "POST", credentials: "include"});
                const data = await response.json();

                if (data.success) {
                    navigate('/login');
                } else {
                    alert('Logout failed');
                }
                setIsLoading(false);
            } catch (error) {
                console.error(error);
                alert('Logout failed');
                setIsLoading(false);
            }
    }

    useEffect(() => {
        const user_id = JSON.parse(localStorage.getItem('ecomm-user'))["_id"];
        const userCart = localStorage.getItem(`ecomm-cart-${user_id}`) ? JSON.parse(localStorage.getItem(`ecomm-cart-${user_id}`)) : {};
        const length = Object.keys(userCart).length;
        setCartCount(length);
    }, []);

    return (
        <nav className="navbar">
            <div className="navbar-container">
                <div className="logo">
                    <h2>ShopEasy</h2>
                </div>

                <ul className="links">
                    <li><a href="/">Home</a></li>
                    <li><a href="/products">Products</a></li>
                    {/* <li><a href="/about">About</a></li>
                    <li><a href="/contact">Contact</a></li> */}
                </ul>

                <div className="cart" onClick={() => navigate('/cart')}>
                    <FontAwesomeIcon icon={faShoppingCart} className='i-replaced-comp' />
                    <span className="cart-quantity">{cartCount}</span>
                </div>

                <div className="dropdown" onClick={() => setShowProfileDropdown(!showProfileDropdown)}>
                    <button className="dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <FontAwesomeIcon icon={faPersonBooth} className='profile-icon' />
                    </button>

                    { showProfileDropdown ? <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <button className="dropdown-item" onClick={logout}>Logout</button>
                    </div> : null}
                </div>


            </div>
        </nav>
    );
}

export default Navbar;

// CSS
