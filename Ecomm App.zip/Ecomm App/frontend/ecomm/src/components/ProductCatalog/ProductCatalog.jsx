import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import "./productCatalog.css";

// Import React Slick Slider
import Slider from 'react-slick';

// Import css files
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useSpinner } from '../../utils/SpinnerContext';


const ProductCatalog = () => {
    const {product_id} = useParams();
    const [product, setProduct] = useState(null);
    const { setIsLoading } = useSpinner();
    const user_id = JSON.parse(localStorage.getItem('ecomm-user'))["_id"];
    // console.log("user_id", user_id);
    const product_cart = localStorage.getItem(`ecomm-cart-${user_id}`) ? JSON.parse(localStorage.getItem(`ecomm-cart-${user_id}`)) : {};
    // console.log(product_cart, "product_cart");
    let isProductInCart = product_cart[product_id] ? true : false;
    const [productInCart, setProductInCart] = useState(product_cart[product_id] ?? { quantity: 0 });
    // console.log(productInCart);

    const settings = {
        dots: true,
        infinite: false,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };

    useEffect(() => {
        const getProduct = async() => {
            setIsLoading(true);
            const response = await fetch(`${import.meta.env.VITE_API_URL}product/${product_id}`, {method: "GET", credentials: "include"});
            const data = await response.json();
            setProduct(data.product);
            setIsLoading(false);
        }
        getProduct();
    }, []);

    const handleAddToCart = async (operation) => {
        setIsLoading(true);
        let set_quantity = 1;
        if(operation === "-") {
            set_quantity = productInCart.quantity - 1;
        } else if(operation === "+") {
            set_quantity = productInCart.quantity + 1;
        }
        const response = await fetch(`${import.meta.env.VITE_API_URL}cart/add/${user_id}`, {method: "POST", credentials: "include", headers: {"Content-Type": "application/json"}, body: JSON.stringify({product_id: product_id, name: product?.name, price: product?.price, quantity: set_quantity})});
        setIsLoading(false);
        const data = await response.json();
        console.log(data);
        if(data.success) {
            if(product_cart && operation === "-") {
                localStorage.setItem(`ecomm-cart-${user_id}`, JSON.stringify({...product_cart, [product_id]: { product_id, price: product?.price, quantity: set_quantity}}));
                setProductInCart(prev =>{
                    return {
                        ...prev,
                        quantity: set_quantity,
                    }
                });
            } else if(product_cart && operation === "+") {
                localStorage.setItem(`ecomm-cart-${user_id}`, JSON.stringify({...product_cart, [product_id]: { product_id, price: product?.price, quantity: set_quantity}}));
                setProductInCart(prev =>{
                    return {
                        ...prev,
                        quantity: set_quantity,
                    }
                });
            }
            else {
                localStorage.setItem(`ecomm-cart-${user_id}`, JSON.stringify({...product_cart, [product_id]: { product_id, price: product?.price, quantity: 1}}));
                setProductInCart({
                    quantity: 1,
                    price: product?.price,
                    product_id: product_id
                });
            }
            alert('Added to cart');
        } else {
            alert('Failed to add to cart');
        }
    }

    return (
        <div className="product-catalog">
            <Link to="/" className="go-back-btn">Go Back</Link>

            <h1 className="product-name">{product?.name}</h1>

            <div className="product-images">
                <Slider {...settings}>
                    {product?.images.map(img => (
                        <div key={img} className='one-image-div'>
                            <img src={img} alt={name} />
                        </div>
                    ))}
                </Slider>
            </div>

            <div className="product-details">
                <div className="price">${product?.price}</div>
                <div className="description">{product?.description}</div>
                <div className="stock">
                    {product?.stock > 0 ? 'In Stock' : 'Out of Stock'}
                </div>
                {isProductInCart && productInCart.quantity > 0? (
                    <div className="cart-count-control">
                        <button onClick={() => handleAddToCart("-")}>-</button>
                        {productInCart?.quantity}
                        <button onClick={() => handleAddToCart("+")}>+</button>
                    </div>
                ) : (
                    <button className="add-to-cart-btn" onClick={() => handleAddToCart("")} disabled={product?.stock <= 0}>
                        Add to Cart
                    </button>
                )}

            </div>

        </div>
    );
}

export default ProductCatalog;
