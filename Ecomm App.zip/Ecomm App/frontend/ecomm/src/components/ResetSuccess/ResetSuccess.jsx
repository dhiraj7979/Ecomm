import React from 'react';
import { Link } from 'react-router-dom';
import './resetSuccess.css';

function ResetSuccess() {
    return (
        <div className="reset-success">
            <h1>Password Reset Successful!</h1>
            <p>Your password has been reset successfully. You can now login with your new password.</p>

            <Link to="/login">
                <button>Login</button>
            </Link>
        </div>
    );
}

export default ResetSuccess;
