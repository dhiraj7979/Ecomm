import React from 'react';
import "./paymentStatus.css";
import { useSearchParams } from 'react-router-dom';

const PaymentStatus = () => {

    const [searchParams] = useSearchParams();
    const isCancelled = searchParams.get('canceled');
    const isSuccess = searchParams.get('success');

    let message;
    let cssClass;

    if (isCancelled) {
        message = 'Your order has been cancelled.';
        cssClass = 'order-cancelled';
    } 
    if (isSuccess) {
        message = 'Your order has been placed successfully!';
        cssClass = 'order-placed';
    }

    return (
        <div className={cssClass}>
            <h2>{message}</h2>
            <p>Please contact us if you have any questions.</p>
        </div>
    );

};


export default PaymentStatus;
