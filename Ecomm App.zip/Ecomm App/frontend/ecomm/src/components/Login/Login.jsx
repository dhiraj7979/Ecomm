import React from 'react';
import './login.css';
import { Link, useNavigate } from 'react-router-dom';

function Login() {
    const navigate = useNavigate();
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [error, setError] = React.useState('');
    const [loading, setLoading] = React.useState(false);


        const handleLogin = async (event) => {
            event.preventDefault();

            try {
                const response = await fetch(`${import.meta.env.VITE_API_URL}auth/login`, {
                    method: 'POST',
                    credentials: "include",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email: event.target.email.value,
                        password: event.target.password.value
                    })
                });

                const data = await response.json();

                if (data.success) {
                    localStorage.setItem('ecomm-user', JSON.stringify(data.user));
                    navigate('/');
                    console.log(data);
                } else {
                    alert('Login failed');
                }

            } catch (error) {
                console.error(error);
            }
        }

    return (
        <div className="login">
            <div className="login-container">
                <h1>Login</h1>

                <form onSubmit={(e) => handleLogin(e)}>
                    <div className="form-group">
                        <label htmlFor="email">Email</label>
                        <input type="email" id="email" onChange={(e) => setEmail(e.target.value)} />
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">Password</label>
                        <input type="password" id="password" onChange={(e) => setPassword(e.target.value)} />
                    </div>

                    <Link to="/forgot_password" style={{textDecoration: "none", textAlign: "right"}}>Forgot Password?</Link>

                    <button style={{marginTop: "8px"}} type="submit" >Login</button>
                </form>
            </div>
        </div>
    );
}

export default Login;
