import React, { useEffect, useState } from 'react';
import "./cart.css";

const Cart = () => {
    // const cartItems = [
    //     { id: 1, name: 'Product 1', price: 9.99, quantity: 1 },
    //     { id: 2, name: 'Product 2', price: 19.99, quantity: 2 },
    //     { id: 3, name: 'Product 3', price: 29.99, quantity: 1 }
    // ];

    const [cartItems, setCartItems] = useState([]);

    
    useEffect(() => {
        const getCart = async() => {
                const user_id = JSON.parse(localStorage.getItem('ecomm-user'))["_id"];
                const response = await fetch(`${import.meta.env.VITE_API_URL}cart/${user_id}`, {method: "GET", credentials: "include"});
                const data = await response.json();
                if(data.success) {
                    setCartItems(data.cart);
                }
                console.log(data);
                return data;
            };

            getCart();
        }, []);
    
    const handleCheckout = async (e) => {
        e.preventDefault();
        const response = await fetch(`${import.meta.env.VITE_API_URL}payment/create-checkout-session`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({userCart: cartItems})
        });
        const data = await response.json();
        if(data.success) {
            console.log(data);
            window.location.href = data.url;
        } else {
            alert('Checkout failed. Please try again.');
        }
    }

    return (
        <div className="cart">
            <h1>Shopping Cart</h1>

            <div className="cart-items">
                {cartItems.map(item => (
                    <div key={item._id} className="cart-item">
                        <h3>{item.name}</h3>
                        <p>${item.price}</p>
                        <p>Quantity: {item.quantity}</p>
                    </div>
                ))}
            </div>

            <p className="total">
                Total: $
                {cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0)}
            </p>
            <form action="http://localhost:9090/payment/create-checkout-session" onSubmit={(e) => handleCheckout(e)}>
                <button disabled={cartItems.length < 1} type="submit">
                    Checkout
                </button>
            </form>
        </div>
    );
};

export default Cart;
