import React, { useEffect } from 'react';
import './productList.css';
import { useNavigate } from 'react-router-dom';

const ProductList = () => {
    const [products, setProducts] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState('');
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`${import.meta.env.VITE_API_URL}product`, {credentials: 'include'})
           .then(res => res.json())
           .then(data => {
            if(data.success) {
                console.log(data.products);
                setProducts(data.products);
            } else if (data.message = "Unauthorized") {
                alert('Please login.');
                navigate("/login");
            }

            })
           .catch(err => {
                console.log(err);
            });
    }, []);

    return (
        <div className="product-list">
            {products.map((product, idx) => (
                <div className="product-card" key={idx} onClick={() => navigate(`/details/${product._id}`)}>
                    <img src={product.images[0]} alt={product.name} />
                    <h3>{product.name}</h3>
                    <p>${product.price}</p>
                </div>
            ))}
        </div>
    );
}

export default ProductList;




    // const products = [
    //     {
    //         id: 1,
    //         name: 'Product 1',
    //         price: 29.99,
    //         image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
    //     },
    //     {
    //         id: 2,
    //         name: 'Product 2',
    //         price: 39.99,
    //         image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1199&q=80'
    //     },
    //     {
    //         id: 3,
    //         name: 'Product 3',
    //         price: 49.99,
    //         image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
    //     },
    //     {
    //         id: 4,
    //         name: 'Product 4',
    //         price: 59.99,
    //         image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
    //     },
    //     {
    //         id: 5,
    //         name: 'Product 5',
    //         price: 69.99,
    //         image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
    //     },
    //     {
    //         id: 6,
    //         name: 'Product 6',
    //         price: 79.99,
    //         image: 'https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
    //     },
    //     {
    //         id: 7,
    //         name: 'Product 7',
    //         price: 89.99,
    //         image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
    //     },
    //     {
    //         id: 8,
    //         name: 'Product 8',
    //         price: 99.99,
    //         image: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
    //     },
    //     {
    //         id: 9,
    //         name: 'Product 9',
    //         price: 109.99,
    //         image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&ixid=MnwxMj'
    //     }
    // ];
