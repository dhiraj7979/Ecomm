import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import "./App.css";
import Register from "./components/Register/Register";
import Login from "./components/Login/Login";
import ForgotPassword from "./components/ForgotPassword/ForgotPassword";
import ResetPassword from "./components/ResetPassword/ResetPassword";
import ResetSuccess from "./components/ResetSuccess/ResetSuccess";
import NotFoundPage from "./components/404Page/404Page";
import ProductList from "./components/ProductList/ProductList";
import ProductCatalog from "./components/ProductCatalog/ProductCatalog";
import Navbar from "./components/Navbar/Navbar";
import PaymentStatus from "./components/PaymentStatus/PaymentStatus";
import Cart from "./components/Cart/Cart";
import { useSpinner } from "./utils/SpinnerContext";
import Spinner from "./components/Spinner/Spinner";

const App = () => {
  const {isLoading} = useSpinner();
  return (
      <BrowserRouter>
        {isLoading && <Spinner />}
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot_password" element={<ForgotPassword />} />
          <Route path="/reset_password" element={<ResetPassword />} />
          <Route path="/reset_password_success" element={<ResetSuccess />} />

          {/* Protected Routes - Needs Auth */}
          <Route path="/" element={<><Navbar /><ProductList /></>} />
          <Route path="/details/:product_id" element={<><Navbar /><ProductCatalog /></>} />
          <Route path="/cart" element={<><Navbar /><Cart /></>} />
          <Route path="/post_trnx" element={<><Navbar /><PaymentStatus /></>} />

          {/* Standard 404 Page */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </BrowserRouter>
  );
}

export default App;


// const ProductDisplay = () => (
//   <section>
//     <div className="product">
//       <img
//         src="https://i.imgur.com/EHyR2nP.png"
//         alt="The cover of Stubborn Attachments"
//       />
//       <div className="description">
//       <h3>Stubborn Attachments</h3>
//       <h5>$20.00</h5>
//       </div>
//     </div>
//     <form action="http://localhost:9090/payment/create-checkout-session" method="POST">
//       <button type="submit">
//         Checkout
//       </button>
//     </form>
//   </section>
// );

// const Message = ({ message }) => (
//   <section>
//     <p>{message}</p>
//   </section>
// );

// export default function App() {
//   const [message, setMessage] = useState("");

//   useEffect(() => {
//     // Check to see if this is a redirect back from Checkout
//     const query = new URLSearchParams(window.location.search);

//     if (query.get("success")) {
//       setMessage("Order placed! You will receive an email confirmation.");
//     }

//     if (query.get("canceled")) {
//       setMessage(
//         "Order canceled -- continue to shop around and checkout when you're ready."
//       );
//     }
//   }, []);

//   return message ? (
//     <Message message={message} />
//   ) : (
//     <ProductDisplay />
//   );
// }