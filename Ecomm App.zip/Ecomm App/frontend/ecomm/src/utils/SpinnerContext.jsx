import { createContext, useContext, useState } from 'react';

const SpinnerContext = createContext();

export const SpinnerProvider = ({ children }) => {
    const [isLoading, setIsLoading] = useState(false);

    const value = {
        isLoading: false,
        setIsLoading: () => {},
    };

    return (
        <SpinnerContext.Provider value={value}>
            {children}
        </SpinnerContext.Provider>
    );
};

export const useSpinner = () => useContext(SpinnerContext);
