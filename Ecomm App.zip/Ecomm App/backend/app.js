const express = require("express");
const app = express();
const bodyParser = require("body-parser");
require("dotenv").config();
const cors = require("cors");
const session = require("express-session");
require("./config/database");

app.use(bodyParser.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
  })
);
app.use(cors(
  {
    origin: [
      "http://localhost:5173",
      "https://checkout.stripe.com"
    ],
    credentials: true,
  }
));

app.get("/", (req, res) => {
  res.status(200).json({
    message: "Welcome to Ecomm backend!",
  });
});

app.use("/cart", require("./routes/cartRoutes"));
app.use("/auth", require("./routes/authRoutes"));
app.use("/product", require("./routes/productRoutes"));
app.use("/payment", require("./routes/paymentRoutes"));

app.listen(process.env.PORT || 3000, () => {
  console.log(`Server listening on port ${process.env.PORT || 3000}`);
});
