const express = require('express');
const {
    getCart,
    addToCart,
    // updateItemQuantity,
    // removeItemFromCart,
    clearCart
} = require('../controllers/cartController');
const { isAuthenticated } = require('../middlewares/authMiddleware');

const router = express.Router();

// GET cart 
router.get('/:user_id', isAuthenticated, getCart);

// ADD item to cart
router.post('/add/:user_id', isAuthenticated, addToCart);

// // UPDATE item in cart
// router.put('/update/:id', isAuthenticated, updateItemQuantity);

// // DELETE item from cart
// router.delete('/delete/:user_id', isAuthenticated, removeItemFromCart);

// CLEAR cart
router.delete('/clear/:user_id', isAuthenticated, clearCart);

module.exports = router;
