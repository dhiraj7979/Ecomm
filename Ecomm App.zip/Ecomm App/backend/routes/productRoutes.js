const express = require("express");
const router = express.Router();

const { isAuthenticated } = require("../middlewares/authMiddleware");
const { addProduct, getAllProducts, updateProduct, deleteProduct, getProductById } = require("../controllers/productController");


// @route GET /products
// @desc Get all products
// @access Private
router.get("/", isAuthenticated, getAllProducts);

// @route GET /products/:id
// @desc Get a product
// @access Private
router.get("/:id", isAuthenticated, getProductById);

// @route POST /products
// @desc Create a product
// @access Private
router.post("/", isAuthenticated, addProduct);

// @route PUT /products/:id
// @desc Update a product
// @access Private
router.put("/:id", isAuthenticated, updateProduct);

// @routes DELETE /products/:id
// @desc Delete a product
// @access Private
router.delete("/:id", isAuthenticated, deleteProduct);

module.exports = router;
