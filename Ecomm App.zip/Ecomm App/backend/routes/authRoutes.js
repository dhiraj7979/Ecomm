const express = require("express");
const router = express.Router();

const { registerNewUser, loginUser, logoutUser, forgotPassword, resetPassword } = require("../controllers/authController");

router.post("/register", registerNewUser);

router.post("/login", loginUser);

router.post("/logout", logoutUser);

router.post("/forgot_password", forgotPassword);

router.post("/reset_password", resetPassword);

module.exports = router;