const express = require("express");
const { createCheckoutSession } = require("../controllers/paymentController");
const { isAuthenticated } = require("../middlewares/authMiddleware");

const router = express.Router();

router.post('/create-checkout-session', createCheckoutSession);
// router.post('/create-checkout-session', isAuthenticated, createCheckoutSession);

module.exports = router;
