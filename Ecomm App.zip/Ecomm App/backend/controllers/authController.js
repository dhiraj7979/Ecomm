const bcrypt = require("bcryptjs");
const { default: mongoose } = require("mongoose");
const crypto = require("crypto");
require("dotenv").config();

const User = require("../models/User");

async function loginUser(req, res) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Invalid credentials",
      });
    }
    if (!(await bcrypt.compare(password, user.password))) {
      return res.status(400).json({
        success: false,
        message: "Invalid credentials",
      });
    }

    req.session.user = user;
    return res.status(200).json({
      success: true,
      message: "Login successful",
      user: user,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
}

async function logoutUser(req, res) {
  try {
    req.session.destroy();
    return res.status(200).json({
      success: true,
      message: "Logout successful",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
}

async function registerNewUser(req, res) {
  try {
    const { name, email, password, re_password } = req.body;

    const user = await User.findOne({ email });
    if (user) {
      return res
        .status(400)
        .json({ success: false, message: "Email already exists" });
    }

    if (password !== re_password) {
      return res
        .status(400)
        .json({ success: false, message: "Passwords do not match" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await User.create({
      name,
      email,
      password: hashedPassword,
    });
    if (newUser) {
      return res
        .status(200)
        .json({ success: true, message: "User created successfully" });
    }
  } catch (err) {
    return res.status(500).json({ success: false, message: err });
  }
}

async function forgotPassword(req, res) {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Invalid email",
      });
    }

    const resetToken = crypto.randomBytes(20).toString("hex");
    user.resetToken = resetToken;
    user.resetTokenExpiration = Date.now() + 10 * 60 * 1000; // 10 minutes
    await user.save();

    const resetUrl = `${process.env.HOST}:${process.env.FE_PORT}/reset_password?token=${resetToken}`;
    const message = `You are receiving this email because you (or someone else) has requested the reset of a password
      for your account. Please click on the following link, or paste this into your browser to complete the process:
      ${resetUrl}`;
    // await sendEmail({
    //   email: user.email,
    //   subject: subject ? "" : "Your password reset token (valid for 10 min)",
    //   message,
    //   html: true,
    // });

    console.log("Email sent");
    console.log("Email body", message);

    return res.json({
      success: true,
      message: "Email sent",
      body: message,
      resetLink: resetUrl,
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

async function resetPassword(req, res) {
  try {
    const { resetToken, newPassword } = req.body;
    const user = await User.findOne({
      resetToken,
      resetTokenExpiration: { $gt: Date.now() },
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Invalid token",
      });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    user.resetToken = null;
    user.resetTokenExpiration = null;
    await user.save();

    return res.status(200).json({
      success: true,
      message: "Password reset successful",
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

module.exports = {
  registerNewUser,
  loginUser,
  logoutUser,
  forgotPassword,
  resetPassword,
};
