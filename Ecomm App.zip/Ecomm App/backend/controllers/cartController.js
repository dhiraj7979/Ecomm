const Cart = require("../models/Cart");
const User = require("../models/User");

// Get cart
exports.getCart = async (req, res) => {
  try {
    const { user_id } = req.params;

    const cartItems = await Cart.find({ user_id });
    return res.json({
      success: true,
      cart: cartItems,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: "Error fetching cart items",
    });
  }
};

// Add item to cart
exports.addToCart = async (req, res) => {
  try {
    const { user_id } = req.params;
    const { product_id, price, quantity, name } = req.body;

    const user = await User.findById(user_id);
    if(!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    const cart = await Cart.findOne({
      user_id: user_id,
      product_id: product_id,
    });
    if (!cart) {
      const newCart = new Cart({
        user_id: user_id,
        product_id: product_id,
        price: price,
        quantity: quantity,
        name: name,
      });
      await newCart.save();
      return res.status(200).json({
        success: true,
        message: "Cart item added successfully",
      });
    } else {
      cart.quantity = quantity;
      cart.price = price;
      await cart.save();
      return res.status(200).json({
        success: true,
        message: "Cart item added successfully",
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};

// Update item quantity in cart
exports.updateItemQuantity = (req, res) => {
  // Access cart from res.advancedResults
  const cart = res.advancedResults;

  // Get item id and new quantity from request body
  const { itemId, newQuantity } = req.body;

  // Find item in cart and update quantity
  const item = cart.items.find((i) => i.id === itemId);
  if (item) {
    item.quantity = newQuantity;
  }

  // Save updated cart
  res.advancedResults = cart;

  res.status(200).json({
    success: true,
    data: cart,
  });
};

// Remove item from cart
exports.removeItemFromCart = (req, res) => {
  // Access cart from res.advancedResults
  const cart = res.advancedResults;

  // Get item id from request params
  const { itemId } = req.params;

  // Filter item out of cart
  cart.items = cart.items.filter((i) => i.id !== itemId);

  // Save updated cart
  res.advancedResults = cart;

  res.status(200).json({
    success: true,
    data: cart,
  });
};

// Clear cart
exports.clearCart = async (req, res) => {
    try {
        // Get user id from request params
        const { userId } = req.params;
      
        // Remove all items from cart
        const cart = await Cart.deleteMany({userId});
        console.log(cart);
      
        res.status(200).json({
          success: true,
          message: "Cart cleared successfully",
        });

    } catch (err) {
        console.log(err);
      res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    }
};
