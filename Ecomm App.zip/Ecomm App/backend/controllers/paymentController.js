require("dotenv").config();
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

const MY_DOMAIN = `${process.env.HOST}:${process.env.FE_PORT}`;

async function createCheckoutSession(req, res) {
  const cart = req.body.userCart;
  let line_items;
  if (cart && cart.length > 0) {
    line_items = cart.map((item) => {
      return {
        price_data: {
          currency: "inr",
          product_data: {
            name: item.name,
          },
          unit_amount: item.price * 100,
        },
        quantity: item.quantity || 1,
      };
    });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      line_items: [...line_items],
      // line_items: [
      //   {
      //     // Provide the exact Price ID (for example, pr_1234) of the product you want to sell
      //     price_data: {
      //       currency: "inr",
      //       product_data: {
      //         name: "T-shirt",
      //       },
      //       unit_amount: 2000,
      //     },
      //     quantity: 1,
      //   },
      // ],
      mode: "payment",
      success_url: `${MY_DOMAIN}/post_trnx?success=true`,
      cancel_url: `${MY_DOMAIN}/post_trnx?canceled=true`,
    });

    // res.redirect(303, session.url);
    return res.status(200).json({
      success: true,
      message: "Checkout session created",
      url: session.url,
    });
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal Server Error" });
  }
}

module.exports = { createCheckoutSession };
