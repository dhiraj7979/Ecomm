const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/ecomm', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log('MongoDB connected...'))
    .catch(err => console.log(err));


module.exports = mongoose.connection;

// const db = mongoose.connection;

// db.once('open', () => {
//     // Now we can run queries!
//     const User = mongoose.model('User', new Schema({ name: String }));

//     User.findOne({ name: 'John' }, (err, user) => {
//         if (err) return handleError(err);
//         console.log(user);
//     });

// });




// const db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error:'));
// db.once('open', function () {
//     // we're connected!
//     console.log('MongoDB connected...');
// });
// module.exports = db;
// module.exports = mongoose.connection;
// module.exports = db;